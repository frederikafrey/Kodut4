﻿using Abc.Facade.Common;

namespace Abc.Facade.Quantity
{
    public sealed class SystemOfUnitsView : DefinedView
    {
    }
}
