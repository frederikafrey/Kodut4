﻿using Abc.Data.Common;

namespace Abc.Data.Money
{
    public sealed class CurrencyData : DefinedEntityData
    {
    }
}
