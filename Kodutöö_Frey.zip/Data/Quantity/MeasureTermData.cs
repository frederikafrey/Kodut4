﻿namespace Abc.Data.Quantity
{
    public sealed class MeasureTermData : CommonTermData
    {
    }
}
