﻿namespace Abc.Aids
{
    public static class ForDemo
    {
        public static int Add(int a, int b) { return a + b; }
    }
}
