﻿using Abc.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Abc.Domain.Quantity
{
    public interface IMeasuresRepository : IRepository<Measure>
    {
    }
}
