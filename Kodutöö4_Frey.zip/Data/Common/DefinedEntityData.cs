﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abc.Data.Common
{
    public class DefinedEntityData : NamedEntityData
    {
        public string Definition { get; set; }
    }
}
