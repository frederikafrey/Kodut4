﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abc.Data.Common
{
    public class UniqueEntityData : PeriodData
    {
        public string Id { get; set; }
    }
}
