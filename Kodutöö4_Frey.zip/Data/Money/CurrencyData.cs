﻿using Abc.Data.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Abc.Data.Money
{
    class CurrencyData : DefinedEntityData
    {
    }
}
