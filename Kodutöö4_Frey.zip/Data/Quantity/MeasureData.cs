﻿using Abc.Data.Common;
using System;

namespace Abc.Data.Quantity
{
    public class MeasureData : DefinedEntityData
    {
    }
}
