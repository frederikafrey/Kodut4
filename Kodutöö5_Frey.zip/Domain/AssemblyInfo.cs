﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Abc.Infra")]